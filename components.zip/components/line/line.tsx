import styles from './line.module.scss';

function Line() {
    return <span className={styles.line}></span>
};

export default Line;