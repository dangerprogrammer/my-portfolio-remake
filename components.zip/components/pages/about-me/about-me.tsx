function AboutMePage() {
    return <section>About Me Page!</section>
}

export default AboutMePage;