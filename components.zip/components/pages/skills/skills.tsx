function SkillsPage() {
    return <section>Skills Page!</section>
}

export default SkillsPage;