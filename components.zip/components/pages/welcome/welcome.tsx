function WelcomeHeader() {
    return <span>Welcome!</span>
}

export default WelcomeHeader;